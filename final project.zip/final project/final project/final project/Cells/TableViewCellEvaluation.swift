//
//  TableViewCellEvaluation.swift
//  final project
//
//  Created by Hamza Amassi on 14/12/2022.
//  Copyright © 2022 userdb. All rights reserved.
//

import UIKit

class TableViewCellEvaluation: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
