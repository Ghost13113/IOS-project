//
//  TableViewCellOrderList.swift
//  final project
//
//  Created by Hamza Amassi on 13/12/2022.
//  Copyright © 2022 userdb. All rights reserved.
//

import UIKit

class TableViewCellOrderList: UITableViewCell {

    static let identifier = "TableViewCellOrderList"
    
    @IBOutlet weak var type: UILabel!    
    @IBOutlet weak var cityandRegion: UILabel!
    @IBOutlet weak var cost: UILabel!
    @IBOutlet weak var img: UIImageView?
    override func awakeFromNib() {
        super.awakeFromNib()
        img?.layer.cornerRadius = 5

        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
