//
//  TableViewCellFavorite.swift
//  final project
//
//  Created by Hamza Amassi on 14/12/2022.
//  Copyright © 2022 userdb. All rights reserved.
//

import UIKit

class TableViewCellFavorite: UITableViewCell {
    static let identifier = "TableViewCellFavorite"

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var city: UILabel!
    @IBOutlet weak var img: UIImageView?
    override func awakeFromNib() {
        super.awakeFromNib()
        //img?.layer.cornerRadius = 30

        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
