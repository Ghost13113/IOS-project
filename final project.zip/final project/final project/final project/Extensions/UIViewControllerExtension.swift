//
//  UIViewControllerExtension.swift
//  final project
//
//  Created by Hamza Amassi on 14/12/2022.
//  Copyright © 2022 userdb. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController{
    func showAlert(_ title:String, isGoodAlert:Bool){
        let alert = UIAlertController(title: "\n\(title)", message: "", preferredStyle: .alert)
        if(isGoodAlert){
            let imgViewtitle = UIImageView(frame: CGRect(x: 120, y: 10, width: 30, height: 30))
            imgViewtitle.image = UIImage(named: "checkmark")
            alert.view.addSubview(imgViewtitle)
        }else{
            let imgViewtitle = UIImageView(frame: CGRect(x: 120, y: 10, width: 30, height: 30))
            imgViewtitle.image = UIImage(named: "deny")
            alert.view.addSubview(imgViewtitle)
        }
        
        
        present(alert, animated: true){
            let tabGesture = UITapGestureRecognizer(target: self, action: #selector(self.dismissAlertController))
            alert.view.superview?.subviews[0].addGestureRecognizer(tabGesture)
        }
        
        
    }
    
    @objc func dismissAlertController(){
        self.dismiss(animated: true,completion: nil)
    }
}
