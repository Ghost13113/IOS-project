
import UIKit

class AddOrderViewController: UIViewController {

    
    @IBOutlet weak var chooseType: UITextField!
    @IBOutlet weak var Region: UITextField!
    @IBOutlet weak var city: UITextField!
    @IBOutlet weak var chooseOganization: UIButton!
    @IBOutlet weak var BuildingSpace: UITextField!
    @IBOutlet weak var roomsNumber: UITextField!
    @IBOutlet weak var floorsNumber: UITextField!
    @IBOutlet weak var Height: UITextField!
    @IBOutlet weak var Cost: UITextField!
    @IBOutlet weak var StructureImage: UIButton!
    
    var organiztion:Organization? = nil
    var image:UIImage? = nil
    
    let types = ["فيلا", "منزل", "شقة"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let pickerView = UIPickerView()
        pickerView.delegate = self
        chooseType.inputView = pickerView

    }
    
    @IBAction func chooseOragnizationClicked(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let organizationsViewController = storyboard.instantiateViewController(withIdentifier: "OrganizationsViewController") as? OrganizationsViewController{
            organizationsViewController.completionBlock = {[weak self] dataReturned in
                self?.organiztion = dataReturned
                self?.chooseOganization.setTitle(dataReturned.name, for: UIControl.State.normal)
            }
            navigationController?.pushViewController(organizationsViewController, animated: true)
        }
    }

    
    
    @IBAction func LocationOnMapClicked(_ sender: Any) {
    }
    
    @IBAction func structureImagePressed(_ sender: Any) {
        let sheet = UIAlertController(title: "Get Image", message: "Select image source", preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: "Cmaera", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .camera
            self.present(picker,animated: true)
        })
        let albumAction = UIAlertAction(title: "Album", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .photoLibrary
            picker.delegate = self
            self.present(picker,animated: true)
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        sheet.addAction(cameraAction)
        sheet.addAction(albumAction)
        sheet.addAction(cancelAction)
        
        present(sheet,animated: true)
    }
    
    @IBAction func AddOrderClicked(_ sender: Any) {
        if(chooseType.hasText && Region.hasText && city.hasText && BuildingSpace.hasText && floorsNumber.hasText && roomsNumber.hasText && Height.hasText && Cost.hasText && organiztion != nil && image != nil){
            let order = Order(type: chooseType.text!, region: Region.text!, city: city.text!, oganization: organiztion!, buildingSpace: BuildingSpace.text!, roomsNumber: roomsNumber.text!, floorsNumber: floorsNumber.text!, height: Height.text!, cost: Cost.text!, structureImage: image)
            Data.currentUser?.orders?.append(order)
            
            showAlert("تم  إرسال الطلب", isGoodAlert: true)
        }else{
            showAlert("يجب تعبئة جميع الخانات", isGoodAlert: false)
        }
    }
}




extension AddOrderViewController: UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return types.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return types[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        chooseType.text = types[row]
    }
    
    
}


extension AddOrderViewController: UIImagePickerControllerDelegate & UINavigationControllerDelegate{
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let img = info[.originalImage] as? UIImage
        self.image = img
        StructureImage.setTitle("تم رفع صورة المخطط", for: UIControl.State.normal)
        picker.dismiss(animated: true)
    }
}
