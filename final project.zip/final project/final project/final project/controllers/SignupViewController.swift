

import UIKit

class SignupViewController: UIViewController {

    @IBOutlet weak var lableIntroductionNumper: UILabel!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var repeatPassword: UITextField!
    @IBOutlet weak var rulesCheck: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        lableIntroductionNumper.layer.cornerRadius = 4

        // Do any additional setup after loading the view.
    }
    

    @IBAction func signupClicked(_ sender: UIButton) {
        if(username.hasText && email.hasText && phone.hasText && password.hasText && repeatPassword.hasText){
            if(!validatePhone(phone.text!)){
                showAlert("ادخل رقم موبايل صالح",isGoodAlert: false)
                return
            }else if(!rulesCheck.isOn){
                showAlert("يجب الموافقة على الشروط و الأحكام",isGoodAlert: false)
                return
            }else if(password.text != repeatPassword.text){
                showAlert("كلمة المرور غير متطابقة",isGoodAlert: false)
                return
            }else{
                // Todo:  save user data
                let user = User(name: username.text!, email: email.text!, phone: phone.text!, password: password.text!)
                Data.users.append(user)
                
                showAlert("تم تسجيل المستخدم",isGoodAlert: true)
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                if let newViewController = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController{
                    newViewController.modalPresentationStyle = .fullScreen
                    self.present(newViewController,animated: true,completion: nil)
                }
            }
            
        }else{ //some fields not entered
            showAlert("جميع الحقول مطلوبة",isGoodAlert: false)
        }
    }
    
    func validatePhone(_ value:String) -> Bool{
        let PHONE_REGEX = "^\\d{3}-\\d{3}-\\d{4}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result = phoneTest.evaluate(with: value)
        return result
    }
    
    
    
}
