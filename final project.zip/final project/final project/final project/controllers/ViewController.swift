

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var companyImage: UIImageView!
    @IBOutlet weak var companyDetImage: UIImageView!
    @IBOutlet weak var radiosName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        companyImage.layer.cornerRadius = 120
        companyDetImage.layer.cornerRadius = 20
        radiosName.layer.cornerRadius = 5
        
    }


}

