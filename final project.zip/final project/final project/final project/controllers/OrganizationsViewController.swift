

import UIKit

class OrganizationsViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    
    var completionBlock: ((_ infoToReturn :Organization) ->())?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "TableViewCellFavorite", bundle: nil), forCellReuseIdentifier: TableViewCellFavorite.identifier)
    }
    
}

extension OrganizationsViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Data.organizations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = table.dequeueReusableCell(withIdentifier: TableViewCellFavorite.identifier, for: indexPath) as? TableViewCellFavorite else{
            return UITableViewCell();
        }

        cell.name.text = Data.organizations[indexPath.row].name
        cell.city.text = Data.organizations[indexPath.row].city
              
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        guard let cb = completionBlock else {return}
        cb(Data.organizations[indexPath.row])
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
}
