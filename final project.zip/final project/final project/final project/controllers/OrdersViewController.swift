

import UIKit

class OrdersViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        table.delegate = self
        table.dataSource = self
        table.register(UINib(nibName: "TableViewCellOrderList", bundle: nil), forCellReuseIdentifier: TableViewCellOrderList.identifier)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        table.reloadData();
    }
    


}



extension OrdersViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let orders = Data.currentUser?.orders{
            return orders.count
        }else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = table.dequeueReusableCell(withIdentifier: TableViewCellOrderList.identifier, for: indexPath) as? TableViewCellOrderList else{
            return UITableViewCell();
        }

        cell.type.text = Data.currentUser?.orders?[indexPath.row].type
        cell.cityandRegion.text = "\(Data.currentUser?.orders?[indexPath.row].city ?? "city"), \(Data.currentUser?.orders?[indexPath.row].region ?? "region")"
        cell.cost.text = Data.currentUser?.orders?[indexPath.row].cost
        cell.img?.image = Data.currentUser?.orders?[indexPath.row].structureImage
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
}
