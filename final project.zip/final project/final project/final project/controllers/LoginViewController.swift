
import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func loginPressed(_ sender: UIButton) {
        var userFound = false
        
        if(email.hasText && password.hasText){
            for user in Data.users{
                if(email.text == user.email && password.text == user.password){
                    userFound = true
                    Data.currentUser = user
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    if let tabBarController = storyboard.instantiateViewController(withIdentifier: "TabBarController") as? UITabBarController{
                        tabBarController.modalPresentationStyle = .fullScreen
                        self.present(tabBarController,animated: true,completion: nil)
                    }
                    
                    break
                }
            }
            if(!userFound){
                showAlert("هناك خطأ في البريد الالكتروني أو كلمة المرور",isGoodAlert: false)
            }
            
        }else{
            showAlert("أدخل البريد و كلمة السر",isGoodAlert: false)
        }
        
    }
    

}
