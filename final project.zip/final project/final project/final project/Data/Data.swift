

import Foundation

class Data{
    static var users:[User] = [User(name: "Ali", email: "Ali@gmail.com", phone: "4348558", password: "123123",orders: [orders[0]]),
                               User(name: "Ahmed", email: "Ahmed@gmail.com", phone: "2457886", password: "123123"),
                               User(name: "a", email: "a", phone: "2457886", password: "a", orders: [orders[0]])]
    static var currentUser:User? = nil
    
    static var organizations = [Organization(name: "Traders", city: "Gaza"),
                                Organization(name: "Ahmed Organizations", city: "Gaza")]
    
    static var orders = [Order(type: "شقة", region: "دبي", city: "دبي", oganization: organizations[0], buildingSpace: "100", roomsNumber: "4", floorsNumber: "2", height: "3",                      cost: "40000", structureImage: nil),
                         Order(type: "فيلا", region: "دبي", city: "دبي", oganization: organizations[0], buildingSpace: "100", roomsNumber: "4", floorsNumber: "2", height: "3", cost: "35000", structureImage: nil)]
    
    
}

