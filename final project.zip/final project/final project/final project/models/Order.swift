//
//  Order.swift
//  final project
//
//  Created by Hamza Amassi on 15/12/2022.
//  Copyright © 2022 userdb. All rights reserved.
//

import Foundation
import UIKit

struct Order{
    var type:String
    var region:String
    var city:String
    var oganization:Organization
    var buildingSpace:String
    var roomsNumber:String
    var floorsNumber:String
    var height:String
    var cost:String
    var structureImage:UIImage?
    
}
