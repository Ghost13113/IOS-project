
import Foundation

class User{
    var name:String
    var email:String
    var phone:String
    var password:String
    var orders:[Order]? = nil
    
//    init(name:String, email:String, phone:String, password:String) {
//        self.name = name
//        self.email = email
//        self.phone = phone
//        self.password = password
//        }
    
    init(name:String, email:String, phone:String, password:String, orders:[Order]? = nil) {
        self.name = name
        self.email = email
        self.phone = phone
        self.password = password
        self.orders = orders
        }
}
