
import Foundation

struct Organization{
    var name:String
    var city:String
}
