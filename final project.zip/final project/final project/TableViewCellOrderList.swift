//
//  TableViewCellOrderList.swift
//  final project
//
//  Created by Hamza Amassi on 13/12/2022.
//  Copyright © 2022 userdb. All rights reserved.
//

import UIKit

class TableViewCellOrderList: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
